import React, { useEffect, useState } from 'react';
import { View, Text, Image, StyleSheet, ScrollView, TouchableOpacity, Linking } from 'react-native';
import * as ScreenOrientation from 'expo-screen-orientation';

export default function App() {
  const [quote, setQuote] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');
  const [musicUrl, setMusicUrl] = useState('');

  useEffect(() => {
    ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT);
    fetchContent();
  }, []);

  const fetchContent = async () => {
    try {
      const quoteRes = await fetch('https://your-netlify-url.netlify.app/quote.txt');
      const quoteText = await quoteRes.text();
      setQuote(quoteText);

      const photoRes = await fetch('https://your-netlify-url.netlify.app/photo.jpg');
      setPhotoUrl(photoRes.url);

      const musicRes = await fetch('https://your-netlify-url.netlify.app/music.txt');
      const musicLink = await musicRes.text();
      setMusicUrl(musicLink);
    } catch (e) {
      setQuote('"You are the love that colors my world."');
      setPhotoUrl('https://placekitten.com/400/400');
      setMusicUrl('https://www.youtube.com/watch?v=JGwWNGJdvx8');
    }
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Forever Yours</Text>
      <Text style={styles.subtitle}>For Ifaida Sakhi Mim</Text>

      <Image source={{ uri: photoUrl }} style={styles.image} />

      <Text style={styles.sectionTitle}>💌 Today's Love Note</Text>
      <Text style={styles.quote}>{quote}</Text>

      <Text style={styles.sectionTitle}>🎵 Romantic Tune</Text>
      <TouchableOpacity onPress={() => Linking.openURL(musicUrl)}>
        <Text style={styles.link}>Play on YouTube</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fffaf5',
    padding: 20,
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#c97e7e',
    marginTop: 20,
  },
  subtitle: {
    fontSize: 18,
    textAlign: 'center',
    color: '#555',
    marginBottom: 20,
  },
  image: {
    width: '100%',
    height: 300,
    borderRadius: 20,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    marginTop: 20,
    color: '#a15c5c',
  },
  quote: {
    fontSize: 18,
    fontStyle: 'italic',
    marginVertical: 15,
    color: '#444',
  },
  link: {
    fontSize: 18,
    color: '#cc4455',
    textDecorationLine: 'underline',
    marginVertical: 10,
  },
});
